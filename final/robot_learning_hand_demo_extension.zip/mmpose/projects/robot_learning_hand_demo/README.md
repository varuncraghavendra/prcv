# Robot Learning Hand Demo Extensions for MMPose

This project folder adds the proposal-specific extensions on top of the working MMPose hand demo setup:

- monocular depth estimation using **Monodepth2** by default
- optional stub path for **Depth Anything V2** integration
- **1€ filtering** for temporal smoothing of 3D keypoints
- **gesture abstraction** for `OPEN PALM` and `GRASP`
- a **modern live dashboard** inspired by robotics telemetry UIs
- **MediaPipe live tracking** as the fast front-end, with optional **MMPose refinement** every N frames

## Why this architecture

The stock `demo/hand3d_internet_demo.py` is useful for validating the InterNet checkpoint, but it is not ideal as a high-FPS webcam teleoperation frontend. In practice:

- MediaPipe gives stable 21-point hand tracking at interactive FPS on CPU.
- Monodepth2 provides dense relative depth from the monocular webcam stream.
- MMPose remains in the loop as an optional slower refinement path, so the project still uses the proposal's original hand-pose stack.

This hybrid design fixes the two problems you saw in the original demo:

- **slow frame rate** for webcam inference
- **all-zero looking predictions / low-utility live telemetry**

## Folder layout

```text
projects/robot_learning_hand_demo/
├── README.md
├── requirements_extra.txt
├── results/
├── checkpoints/
├── scripts/
│   └── run_robot_learning_gui.py
└── src/
    ├── camera.py
    ├── depth_estimator.py
    ├── gesture_abstraction.py
    ├── monodepth2_networks.py
    ├── one_euro_filter.py
    ├── pipeline.py
    └── pose_backends.py
```

## Extra setup

From the MMPose repo root:

```bash
source ~/venvs/mmpose-hand3d/bin/activate
export PYTHONNOUSERSITE=1
pip install -r projects/robot_learning_hand_demo/requirements_extra.txt
```

If `PySide6` or `pyqtgraph` are not needed, the current launcher still works with OpenCV-only rendering.

## Monodepth2 weights

Place Monodepth2 weights under:

```text
projects/robot_learning_hand_demo/checkpoints/mono_640x192/
├── encoder.pth
└── depth.pth
```

If weights are missing, the pipeline falls back to a lightweight gradient depth heuristic so the live GUI still runs.

## Run

```bash
cd /path/to/mmpose
python projects/robot_learning_hand_demo/scripts/run_robot_learning_gui.py \
  --device cpu \
  --hands 2 \
  --depth-model projects/robot_learning_hand_demo/checkpoints/mono_640x192 \
  --depth-backend monodepth2 \
  --refine-every-n 12 \
  --save-json
```

## Keyboard controls

- `q` or `Esc`: quit
- `s`: save snapshot into `projects/robot_learning_hand_demo/results/`

## Outputs

The dashboard shows:

- live skeleton overlay
- gesture state
- approximate wrist 3D coordinates
- thumb-index distance as a gripper-width proxy
- dense depth thumbnail
- FPS and backend telemetry

When `--save-json` is enabled, the latest live state is also written to:

```text
projects/robot_learning_hand_demo/results/latest_state.json
```

## Proposal mapping

### MMPose / InterNet baseline

The existing MMPose InterNet config and checkpoint remain the baseline hand-pose source. The new pipeline optionally loads them via `MMPoseRefiner`.

### Depth estimation

The proposal mentioned Depth Anything V2, while the implementation request asked for Monodepth2. This project therefore supports:

- **Monodepth2 as the default implementation path**
- **Depth Anything V2 as an extension point** in `depth_estimator.py`

### 1€ Filter

Implemented in `src/one_euro_filter.py` and applied per joint, per dimension in `pipeline.py`.

### Gesture abstraction

Implemented in `src/gesture_abstraction.py` using:

- finger extension logic
- thumb–index distance
- palm normal estimation

It outputs:

- `OPEN PALM`
- `GRASP`
- `PARTIAL`
- `NO HAND`

## Notes

This extension is designed to be a **project-ready research prototype**, not just a demo script. It prioritizes stable live interaction, modular code, and easy future integration with ROS 2, robot gripper control, or demonstration logging.
