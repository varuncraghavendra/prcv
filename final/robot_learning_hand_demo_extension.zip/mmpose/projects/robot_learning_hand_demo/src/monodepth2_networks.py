"""Minimal Monodepth2 network definitions copied for local project use.

These are intentionally lightweight wrappers around the encoder/decoder used in the
existing MediaPipe-based prototype so the project folder remains self-contained.
"""

import numpy as np
import torch
import torch.nn as nn
import torchvision.models as models


class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, 1, 1),
            nn.ELU(inplace=True),
        )

    def forward(self, x):
        return self.conv(x)


class ResnetEncoder(nn.Module):
    def __init__(self, num_layers, pretrained):
        super().__init__()
        resnets = {18: models.resnet18, 34: models.resnet34, 50: models.resnet50}
        self.encoder = resnets[num_layers](weights=None if not pretrained else "DEFAULT")
        self.num_ch_enc = np.array([64, 64, 128, 256, 512])

    def forward(self, input_image):
        self.features = []
        x = (input_image - 0.45) / 0.225
        x = self.encoder.conv1(x)
        x = self.encoder.bn1(x)
        self.features.append(self.encoder.relu(x))
        self.features.append(self.encoder.layer1(self.encoder.maxpool(self.features[-1])))
        self.features.append(self.encoder.layer2(self.features[-1]))
        self.features.append(self.encoder.layer3(self.features[-1]))
        self.features.append(self.encoder.layer4(self.features[-1]))
        return self.features


class Conv3x3(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.pad = nn.ReflectionPad2d(1)
        self.conv = nn.Conv2d(in_channels, out_channels, 3)

    def forward(self, x):
        return self.conv(self.pad(x))


class DepthDecoder(nn.Module):
    def __init__(self, num_ch_enc, scales=range(4), num_output_channels=1):
        super().__init__()
        self.scales = scales
        self.num_output_channels = num_output_channels
        self.num_ch_enc = num_ch_enc
        self.num_ch_dec = np.array([16, 32, 64, 128, 256])
        self.convs = nn.ModuleDict()
        for i in range(4, -1, -1):
            num_ch_in = self.num_ch_enc[-1] if i == 4 else self.num_ch_dec[i + 1]
            self.convs[f"upconv_{i}_0"] = ConvBlock(num_ch_in, self.num_ch_dec[i])
            num_ch_in = self.num_ch_dec[i]
            if i > 0:
                num_ch_in += self.num_ch_enc[i - 1]
            self.convs[f"upconv_{i}_1"] = ConvBlock(num_ch_in, self.num_ch_dec[i])
        for s in self.scales:
            self.convs[f"dispconv_{s}"] = Conv3x3(self.num_ch_dec[s], self.num_output_channels)
        self.sigmoid = nn.Sigmoid()

    def forward(self, input_features):
        self.outputs = {}
        x = input_features[-1]
        for i in range(4, -1, -1):
            x = self.convs[f"upconv_{i}_0"](x)
            x = [nn.functional.interpolate(x, scale_factor=2, mode="nearest")]
            if i > 0:
                x += [input_features[i - 1]]
            x = torch.cat(x, 1)
            x = self.convs[f"upconv_{i}_1"](x)
            if i in self.scales:
                self.outputs[("disp", i)] = self.sigmoid(self.convs[f"dispconv_{i}"](x))
        return self.outputs
