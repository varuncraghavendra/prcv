from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import cv2
import numpy as np


@dataclass
class HandResult:
    kp2d: np.ndarray
    scores: np.ndarray
    handedness: str
    kp3d_mmpose: Optional[np.ndarray] = None


class MediaPipePoseBackend:
    def __init__(self, max_hands: int = 2, model_complexity: int = 0):
        import mediapipe as mp
        self.mp = mp
        self.hands = mp.solutions.hands.Hands(
            static_image_mode=False,
            max_num_hands=max_hands,
            min_detection_confidence=0.55,
            min_tracking_confidence=0.45,
            model_complexity=model_complexity,
        )

    def predict(self, frame_bgr: np.ndarray, max_hands: int = 2) -> List[HandResult]:
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        res = self.hands.process(rgb)
        out: List[HandResult] = []
        if not res.multi_hand_landmarks:
            return out
        H, W = frame_bgr.shape[:2]
        handed = res.multi_handedness or []
        for idx, landmarks in enumerate(res.multi_hand_landmarks[:max_hands]):
            coords = np.array([(lm.x * W, lm.y * H) for lm in landmarks.landmark], dtype=np.float32)
            scores = np.array([getattr(lm, "visibility", 1.0) if getattr(lm, "visibility", None) is not None else 1.0
                               for lm in landmarks.landmark], dtype=np.float32)
            handedness = "Right"
            if idx < len(handed):
                handedness = handed[idx].classification[0].label
            out.append(HandResult(coords, scores, handedness))
        return out

    def close(self):
        self.hands.close()


class MMPoseRefiner:
    """Optional slow-path MMPose refinement.

    To keep live FPS usable, this is designed to run every Nth frame. It loads the same
    InterNet config/checkpoint as the original demo and returns 3D keypoints when available.
    """

    def __init__(self, config: str, checkpoint: str, device: str = "cpu"):
        self.enabled = False
        self.model = None
        try:
            from mmpose.apis import init_model, inference_topdown
            self.init_model = init_model
            self.inference_topdown = inference_topdown
            self.model = self.init_model(config, checkpoint, device=device)
            self.enabled = True
        except Exception:
            self.enabled = False

    def predict(self, frame_bgr: np.ndarray) -> Optional[np.ndarray]:
        if not self.enabled:
            return None
        try:
            results = self.inference_topdown(self.model, frame_bgr)
            if not results:
                return None
            pred = results[0].pred_instances
            if hasattr(pred, "keypoints"):
                kp = np.asarray(pred.keypoints[0], dtype=np.float32)
                return kp
        except Exception:
            return None
        return None
