from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, Optional

import cv2
import numpy as np

from .depth_estimator import DepthEstimator
from .gesture_abstraction import GestureAbstractor, GestureState
from .one_euro_filter import OneEuroFilter
from .pose_backends import HandResult, MediaPipePoseBackend, MMPoseRefiner

SKELETON = [
    (0, 1), (1, 2), (2, 3), (3, 4),
    (0, 5), (5, 6), (6, 7), (7, 8),
    (0, 9), (9, 10), (10, 11), (11, 12),
    (0, 13), (13, 14), (14, 15), (15, 16),
    (0, 17), (17, 18), (18, 19), (19, 20),
    (5, 9), (9, 13), (13, 17),
]


@dataclass
class HandTrack:
    handedness: str
    filters: list = field(default_factory=list)
    kp2d: Optional[np.ndarray] = None
    kp3d: Optional[np.ndarray] = None
    gesture: Optional[GestureState] = None
    scores: Optional[np.ndarray] = None
    last_seen: float = 0.0

    def __post_init__(self):
        if not self.filters:
            self.filters = [[OneEuroFilter() for _ in range(3)] for _ in range(21)]

    def smooth(self, kp3d: np.ndarray, dt: float) -> np.ndarray:
        out = kp3d.copy()
        for i in range(21):
            for d in range(3):
                out[i, d] = self.filters[i][d](float(kp3d[i, d]), dt)
        return out


class RobotLearningHandPipeline:
    def __init__(self, mmpose_config: str, mmpose_checkpoint: str, device: str = "cpu",
                 max_hands: int = 2, depth_model: str = "mono_640x192",
                 depth_backend: str = "monodepth2", refine_every_n: int = 10):
        self.pose = MediaPipePoseBackend(max_hands=max_hands, model_complexity=0)
        self.depth = DepthEstimator(model_path=depth_model, device=device, backend=depth_backend)
        self.gesture = GestureAbstractor()
        self.mmpose = MMPoseRefiner(mmpose_config, mmpose_checkpoint, device=device)
        self.max_hands = max_hands
        self.refine_every_n = max(1, refine_every_n)
        self.frame_index = 0
        self.fps = 0.0
        self.last_time = time.time()
        self.tracks: Dict[str, HandTrack] = {}
        self.latest_depth: Optional[np.ndarray] = None
        self.latest_overlay: Optional[np.ndarray] = None
        self.latest_payload: Dict = {}

    def process(self, frame_bgr: np.ndarray) -> Dict:
        t = time.time()
        dt = max(t - self.last_time, 1e-6)
        self.last_time = t
        self.fps = 1.0 / dt
        self.frame_index += 1

        frame_bgr = cv2.flip(frame_bgr, 1)
        detections = self.pose.predict(frame_bgr, max_hands=self.max_hands)
        self.latest_depth = self.depth.estimate(frame_bgr)
        mmpose_kp3d = None
        if self.mmpose.enabled and self.frame_index % self.refine_every_n == 0:
            mmpose_kp3d = self.mmpose.predict(frame_bgr)

        payload = {"hands": [], "fps": self.fps, "pose_backend": "mediapipe", "depth_backend": self.depth.backend,
                   "mmpose_refiner": self.mmpose.enabled}
        overlay = self._draw_shell(frame_bgr)

        H, W = frame_bgr.shape[:2]
        fx = fy = float(max(H, W))
        cx, cy = W / 2.0, H / 2.0

        for det in detections:
            track = self.tracks.setdefault(det.handedness, HandTrack(det.handedness))
            kp3d = np.zeros((21, 3), np.float32)
            for i, (u, v) in enumerate(det.kp2d):
                uu = int(np.clip(u, 0, W - 1))
                vv = int(np.clip(v, 0, H - 1))
                z = float(self.latest_depth[vv, uu])
                kp3d[i] = [(u - cx) * z / fx, (v - cy) * z / fy, z]
            if mmpose_kp3d is not None and mmpose_kp3d.shape[0] == 42:
                # InterNet can return two hands; keep MediaPipe live path stable and skip ambiguous fusion.
                pass
            elif mmpose_kp3d is not None and mmpose_kp3d.shape[0] >= 21:
                z_refine = mmpose_kp3d[:21, 2]
                z_refine = z_refine - z_refine.min() + 0.25
                kp3d[:, 2] = 0.55 * kp3d[:, 2] + 0.45 * z_refine
            kp3d = track.smooth(kp3d, dt)
            gesture = self.gesture.classify(kp3d)
            track.kp2d = det.kp2d
            track.kp3d = kp3d
            track.scores = det.scores
            track.gesture = gesture
            track.last_seen = t
            self._draw_hand(overlay, track)
            payload["hands"].append({
                "handedness": det.handedness,
                "gesture": self.gesture.as_dict(gesture),
                "wrist": kp3d[0].round(4).tolist(),
                "thumb_tip": kp3d[4].round(4).tolist(),
                "index_tip": kp3d[8].round(4).tolist(),
                "gripper_width": round(float(np.linalg.norm(kp3d[4] - kp3d[8])), 4),
            })

        self._draw_sidebar(overlay, payload)
        self.latest_overlay = overlay
        self.latest_payload = payload
        return payload

    def _draw_shell(self, frame: np.ndarray) -> np.ndarray:
        vis = frame.copy()
        h, w = vis.shape[:2]
        cv2.rectangle(vis, (0, 0), (w, 60), (18, 22, 28), -1)
        cv2.rectangle(vis, (w - 310, 60), (w, h), (24, 29, 36), -1)
        cv2.putText(vis, "Hand Teleop / Robot Learning Dashboard", (20, 38),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.85, (235, 240, 245), 2, cv2.LINE_AA)
        cv2.putText(vis, "MediaPipe live tracking + MMPose refinement + monocular depth", (20, 54),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (137, 155, 174), 1, cv2.LINE_AA)
        return vis

    def _draw_hand(self, vis: np.ndarray, track: HandTrack):
        kp2d = track.kp2d
        if kp2d is None:
            return
        hand_color = (84, 192, 255) if track.handedness == "Right" else (255, 183, 77)
        for a, b in SKELETON:
            pa = tuple(kp2d[a].astype(int))
            pb = tuple(kp2d[b].astype(int))
            cv2.line(vis, pa, pb, hand_color, 2, cv2.LINE_AA)
        for i, pt in enumerate(kp2d.astype(int)):
            r = 7 if i in [4, 8, 12, 16, 20] else 4
            cv2.circle(vis, tuple(pt), r, (250, 250, 250), -1, cv2.LINE_AA)
            cv2.circle(vis, tuple(pt), r, hand_color, 1, cv2.LINE_AA)
        label = f"{track.handedness} | {track.gesture.label if track.gesture else 'NO HAND'}"
        anchor = kp2d[0].astype(int) + np.array([12, 24])
        cv2.putText(vis, label, tuple(anchor), cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                    (255, 255, 255), 2, cv2.LINE_AA)

    def _draw_sidebar(self, vis: np.ndarray, payload: Dict):
        h, w = vis.shape[:2]
        x0 = w - 292
        y = 92
        def line(text, color=(220, 228, 236), scale=0.48, dy=24, bold=False):
            nonlocal y
            thickness = 2 if bold else 1
            cv2.putText(vis, text, (x0, y), cv2.FONT_HERSHEY_SIMPLEX, scale, color, thickness, cv2.LINE_AA)
            y += dy

        line(f"FPS: {payload['fps']:.1f}", (111, 230, 170), 0.7, 30, True)
        line(f"Pose: {payload['pose_backend']}")
        line(f"Depth: {payload['depth_backend']}")
        line(f"MMPose refine: {'ON' if payload['mmpose_refiner'] else 'OFF'}")
        y += 8
        for idx, hand in enumerate(payload["hands"]):
            line(f"Hand {idx + 1}: {hand['handedness']}", (255, 202, 110), 0.58, 26, True)
            line(f"Gesture: {hand['gesture']['label']}")
            line(f"Openness: {hand['gesture']['openness']}")
            line(f"Grip width: {hand['gripper_width']} m")
            wrist = hand['wrist']
            line(f"Wrist xyz: {wrist[0]:+.2f}, {wrist[1]:+.2f}, {wrist[2]:.2f}")
            y += 8
        if self.latest_depth is not None:
            thumb = self._depth_thumbnail(self.latest_depth)
            th, tw = thumb.shape[:2]
            vis[vis.shape[0]-th-16:vis.shape[0]-16, x0: x0+tw] = thumb

    def _depth_thumbnail(self, depth: np.ndarray) -> np.ndarray:
        norm = ((depth - depth.min()) / max(depth.max() - depth.min(), 1e-6) * 255).astype(np.uint8)
        thumb = cv2.resize(cv2.applyColorMap(norm, cv2.COLORMAP_TURBO), (260, 150))
        cv2.putText(thumb, 'Depth map', (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2, cv2.LINE_AA)
        return thumb

    def close(self):
        self.pose.close()
