from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

import numpy as np

WRIST = 0
THUMB_TIP, THUMB_MCP = 4, 2
INDEX_MCP, INDEX_PIP, INDEX_TIP = 5, 6, 8
MIDDLE_PIP, MIDDLE_TIP = 10, 12
RING_PIP, RING_TIP = 14, 16
PINKY_PIP, PINKY_TIP = 18, 20
PINKY_MCP = 17


def _dist(kp: np.ndarray, i: int, j: int) -> float:
    return float(np.linalg.norm(kp[i] - kp[j]))


@dataclass
class GestureState:
    label: str
    score: float
    thumb_index_distance: float
    palm_normal: np.ndarray
    openness: float


class GestureAbstractor:
    """High-level gesture state from 21 hand keypoints.

    Uses the project proposal cues:
    - thumb tip distances to fingertip set
    - palm orientation vector
    - open-palm vs grasp abstraction
    """

    def __init__(self, curl_margin: float = 0.0, open_thresh: int = 4,
                 grasp_thresh: int = 1):
        self.curl_margin = curl_margin
        self.open_thresh = open_thresh
        self.grasp_thresh = grasp_thresh

    def classify(self, kp3d: np.ndarray | None) -> GestureState:
        if kp3d is None or kp3d.shape[0] < 21:
            return GestureState("NO HAND", 0.0, 0.0, np.zeros(3), 0.0)

        kp2d = kp3d[:, :2]
        extended = self._count_extended(kp2d)
        openness = extended / 5.0
        label = "PARTIAL"
        score = 0.5
        if extended >= self.open_thresh:
            label = "OPEN PALM"
            score = min(1.0, 0.65 + 0.08 * extended)
        elif extended <= self.grasp_thresh:
            label = "GRASP"
            score = min(1.0, 0.7 + 0.1 * (5 - extended))

        thumb_index = _dist(kp3d, THUMB_TIP, INDEX_TIP)
        palm_normal = self.palm_normal(kp3d)
        return GestureState(label, score, thumb_index, palm_normal, openness)

    def _count_extended(self, kp2d: np.ndarray) -> int:
        count = 0
        if self._thumb_extended(kp2d):
            count += 1
        for tip_idx, pip_idx in [
            (INDEX_TIP, INDEX_PIP),
            (MIDDLE_TIP, MIDDLE_PIP),
            (RING_TIP, RING_PIP),
            (PINKY_TIP, PINKY_PIP),
        ]:
            if kp2d[tip_idx, 1] < kp2d[pip_idx, 1] - self.curl_margin:
                count += 1
        return count

    def _thumb_extended(self, kp2d: np.ndarray) -> bool:
        dist_tip_imcp = _dist(kp2d, THUMB_TIP, INDEX_MCP)
        dist_tmcp_imcp = _dist(kp2d, THUMB_MCP, INDEX_MCP)
        return dist_tip_imcp > 0.8 * max(dist_tmcp_imcp, 1e-6)

    def palm_normal(self, kp3d: np.ndarray) -> np.ndarray:
        v1 = kp3d[INDEX_MCP] - kp3d[WRIST]
        v2 = kp3d[PINKY_MCP] - kp3d[WRIST]
        n = np.cross(v1, v2)
        norm = np.linalg.norm(n)
        return n / norm if norm > 1e-8 else np.zeros(3)

    def as_dict(self, state: GestureState) -> Dict[str, float | str | list]:
        return {
            "label": state.label,
            "score": round(state.score, 3),
            "thumb_index_distance": round(state.thumb_index_distance, 4),
            "openness": round(state.openness, 3),
            "palm_normal": state.palm_normal.tolist(),
        }
