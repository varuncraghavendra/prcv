from __future__ import annotations

import threading
import time
from typing import Optional

import cv2


class ThreadedCamera:
    def __init__(self, index: int = 0, width: int = 960, height: int = 540):
        self.cap = cv2.VideoCapture(index, cv2.CAP_V4L2)
        if not self.cap.isOpened():
            self.cap = cv2.VideoCapture(index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_FPS, 30)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        self.frame = None
        self.ok = False
        self.stopped = False
        self._thread: Optional[threading.Thread] = None

    def start(self):
        self._thread = threading.Thread(target=self._reader, daemon=True)
        self._thread.start()
        return self

    def _reader(self):
        while not self.stopped:
            ok, frame = self.cap.read()
            self.ok = ok
            if ok:
                self.frame = frame
            else:
                time.sleep(0.01)

    def read(self):
        return self.ok, None if self.frame is None else self.frame.copy()

    def release(self):
        self.stopped = True
        if self._thread is not None:
            self._thread.join(timeout=0.2)
        self.cap.release()
