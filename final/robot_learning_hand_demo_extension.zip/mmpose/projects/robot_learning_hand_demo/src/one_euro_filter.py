import math
from typing import Optional


class _LowPassFilter:
    def __init__(self):
        self._y: Optional[float] = None

    def __call__(self, x: float, alpha: float) -> float:
        if self._y is None:
            self._y = x
        else:
            self._y = alpha * x + (1.0 - alpha) * self._y
        return self._y

    @property
    def value(self) -> float:
        return 0.0 if self._y is None else self._y

    def reset(self):
        self._y = None


class OneEuroFilter:
    """1€ filter for a single scalar stream."""

    def __init__(self, freq: float = 30.0, min_cutoff: float = 1.2,
                 beta: float = 0.01, d_cutoff: float = 1.0):
        self._freq = float(freq)
        self._min_cutoff = float(min_cutoff)
        self._beta = float(beta)
        self._d_cutoff = float(d_cutoff)
        self._x = _LowPassFilter()
        self._dx = _LowPassFilter()

    @staticmethod
    def _alpha(cutoff: float, freq: float) -> float:
        tau = 1.0 / (2.0 * math.pi * cutoff)
        te = 1.0 / freq
        return 1.0 / (1.0 + tau / te)

    def __call__(self, x: float, dt: Optional[float] = None) -> float:
        if dt and dt > 1e-6:
            self._freq = 1.0 / dt
        prev_x = self._x.value
        raw_dx = (x - prev_x) * self._freq if self._x._y is not None else 0.0
        edx = self._dx(raw_dx, self._alpha(self._d_cutoff, self._freq))
        cutoff = self._min_cutoff + self._beta * abs(edx)
        return self._x(x, self._alpha(cutoff, self._freq))

    def reset(self):
        self._x.reset()
        self._dx.reset()
