from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import cv2
import numpy as np


class DepthEstimator:
    """Monocular depth wrapper.

    Default backend is Monodepth2-style inference if weights are available.
    If not, it falls back to a fast gradient heuristic so the GUI stays live.
    An optional Depth Anything V2 backend can be wired later by passing
    backend='depth_anything_v2' and supplying a compatible local checkpoint.
    """

    def __init__(self, model_path: str = "mono_640x192", device: str = "cpu",
                 min_depth: float = 0.25, max_depth: float = 1.4,
                 backend: str = "monodepth2"):
        self.model_path = model_path
        self.device = device
        self.min_depth = min_depth
        self.max_depth = max_depth
        self.backend = "gradient"
        self.scale = 1.0
        self._encoder = None
        self._decoder = None
        self._feed_width = 640
        self._feed_height = 192
        self._torch = None
        if backend == "depth_anything_v2":
            if not self._try_depth_anything(model_path):
                self._try_monodepth2(model_path)
        else:
            self._try_monodepth2(model_path)

    def _try_depth_anything(self, model_path: str) -> bool:
        try:
            import torch  # noqa: F401
            # Lightweight stub: keeps extension point explicit without forcing a hard dependency.
            if not Path(model_path).exists():
                return False
            self.backend = "depth_anything_v2_stub"
            return True
        except Exception:
            return False

    def _try_monodepth2(self, model_path: str) -> bool:
        try:
            import torch
            from .monodepth2_networks import DepthDecoder, ResnetEncoder
        except Exception:
            return False

        model_dir = Path(model_path)
        encoder_pth = model_dir / "encoder.pth"
        depth_pth = model_dir / "depth.pth"
        if not encoder_pth.exists() or not depth_pth.exists():
            return False

        self._torch = torch
        self._encoder = ResnetEncoder(18, False)
        loaded_dict_enc = torch.load(str(encoder_pth), map_location=self.device)
        self._feed_height = loaded_dict_enc.get("height", 192)
        self._feed_width = loaded_dict_enc.get("width", 640)
        filtered_dict_enc = {k: v for k, v in loaded_dict_enc.items() if k in self._encoder.state_dict()}
        self._encoder.load_state_dict(filtered_dict_enc)
        self._encoder.to(self.device).eval()

        self._decoder = DepthDecoder(num_ch_enc=self._encoder.num_ch_enc, scales=range(4))
        loaded_dict = torch.load(str(depth_pth), map_location=self.device)
        self._decoder.load_state_dict(loaded_dict)
        self._decoder.to(self.device).eval()
        self.backend = "monodepth2"
        return True

    def set_scale(self, scale: float):
        if scale > 0:
            self.scale = scale

    def estimate(self, frame: np.ndarray) -> np.ndarray:
        if self.backend == "monodepth2" and self._encoder is not None:
            try:
                return self._estimate_monodepth2(frame)
            except Exception:
                self.backend = "gradient"
        return self._gradient_depth(frame)

    def _estimate_monodepth2(self, frame: np.ndarray) -> np.ndarray:
        torch = self._torch
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        H, W = rgb.shape[:2]
        input_image = cv2.resize(rgb, (self._feed_width, self._feed_height)).astype(np.float32) / 255.0
        input_tensor = torch.from_numpy(input_image).permute(2, 0, 1).unsqueeze(0).to(self.device)
        with torch.no_grad():
            features = self._encoder(input_tensor)
            outputs = self._decoder(features)
            disp = outputs[("disp", 0)]
        disp_np = disp.squeeze().cpu().numpy()
        disp_resized = cv2.resize(disp_np, (W, H), interpolation=cv2.INTER_LINEAR)
        disp_resized = np.clip(disp_resized, 1e-6, None)
        depth = 1.0 / disp_resized
        dmin, dmax = float(depth.min()), float(depth.max())
        norm = (depth - dmin) / max(dmax - dmin, 1e-6)
        metres = self.min_depth + (1.0 - norm) * (self.max_depth - self.min_depth)
        return (metres * self.scale).astype(np.float32)

    def _gradient_depth(self, frame: np.ndarray) -> np.ndarray:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
        H, W = gray.shape
        yy = np.linspace(0.0, 1.0, H, dtype=np.float32)[:, None]
        xx = np.linspace(0.0, 1.0, W, dtype=np.float32)[None, :]
        cue = 0.55 * (1.0 - gray) + 0.35 * yy + 0.10 * np.abs(xx - 0.5)
        cue = (cue - cue.min()) / max(cue.max() - cue.min(), 1e-6)
        depth = self.min_depth + cue * (self.max_depth - self.min_depth)
        return (depth * self.scale).astype(np.float32)
