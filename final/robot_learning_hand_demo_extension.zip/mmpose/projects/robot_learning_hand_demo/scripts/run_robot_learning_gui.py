#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import cv2

ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT.parents[1]
sys.path.insert(0, str(ROOT))

from src.camera import ThreadedCamera
from src.pipeline import RobotLearningHandPipeline


def parse_args():
    ap = argparse.ArgumentParser(description="Robot learning hand demo GUI")
    ap.add_argument("--camera", type=int, default=0)
    ap.add_argument("--width", type=int, default=960)
    ap.add_argument("--height", type=int, default=540)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--hands", type=int, default=2, choices=[1, 2])
    ap.add_argument("--depth-model", default=str(ROOT / "checkpoints" / "mono_640x192"))
    ap.add_argument("--depth-backend", default="monodepth2", choices=["monodepth2", "depth_anything_v2"])
    ap.add_argument("--refine-every-n", type=int, default=12)
    ap.add_argument("--save-json", action="store_true")
    return ap.parse_args()


def main():
    args = parse_args()
    config = REPO_ROOT / "configs/hand_3d_keypoint/internet/interhand3d/internet_res50_4xb16-20e_interhand3d-256x256.py"
    checkpoint = REPO_ROOT / "checkpoints/res50_intehand3dv1.0_all_256x256-42b7f2ac_20210702.pth"
    pipeline = RobotLearningHandPipeline(
        mmpose_config=str(config),
        mmpose_checkpoint=str(checkpoint),
        device=args.device,
        max_hands=args.hands,
        depth_model=args.depth_model,
        depth_backend=args.depth_backend,
        refine_every_n=args.refine_every_n,
    )
    cam = ThreadedCamera(args.camera, args.width, args.height).start()
    window = "Robot Learning Hand Demo"
    cv2.namedWindow(window, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window, args.width, args.height)
    out_dir = ROOT / "results"
    out_dir.mkdir(exist_ok=True)
    last_dump = 0.0
    try:
        while True:
            ok, frame = cam.read()
            if not ok or frame is None:
                time.sleep(0.01)
                continue
            payload = pipeline.process(frame)
            vis = pipeline.latest_overlay
            cv2.imshow(window, vis)
            key = cv2.waitKey(1) & 0xFF
            if key in (27, ord('q')):
                break
            if key == ord('s'):
                ts = int(time.time())
                cv2.imwrite(str(out_dir / f"snapshot_{ts}.png"), vis)
            if args.save_json and time.time() - last_dump > 0.2:
                (out_dir / "latest_state.json").write_text(json.dumps(payload, indent=2))
                last_dump = time.time()
    finally:
        cam.release()
        pipeline.close()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
